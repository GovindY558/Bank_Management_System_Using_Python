###########           Create A class as a name  Bank.....          ##########

class Bank:
    def __init__(self):                ## Make a Constructor , Then.....
        self.client_details_list = []  ## Make a client_details_list.....
        self.loggedin = False
        self.amount = 100                ## minimum amount = 100
        self.TransferAmount = False



##### Create a Function for Registration as a name of register.....

    def register(self, name , phone , password):
        amount = self.amount
        conditions = True
        if len(str(phone)) > 10 or len(str(phone)) < 10:  ## Check condition for phone number.....
            print("Invalid Phone number ! please enter 10 digit number.")
            conditions = False

        if len(password) < 5 or len(password) > 15:  ## Check Condition For Password.....
            print("Enter Password greater than 5 and less than 15 Number.")
            conditions = False  
        
        if conditions == True:
            print("Account Created successfully...")
            self.client_details_list = [name , phone , password , amount]   ## Store Information of User in the File.....
            with open(f"{name}.txt","w") as f:                            ## Open a new file to store Information of User.....
                for details in self.client_details_list:
                    f.write(str(details)+"\n")               ## Store Details in the File.....




##### The Code Below, Which is for the User Deposit an Amount.....  #####


## Create a New Function or Method for Login,  as a name login.....

    def login(self, name , phone , password):
        with open(f"{name}.txt","r") as f:        ## First of all Open a file as a "r" ("read") Mode.....
            details = f.read()                    ## read Details, From create file, in ( "f.read()" ).....
            self.client_details_list = details.split("\n")  ## Store Details Thorough split method.....
            if str(phone) in str(self.client_details_list):  ## Check Details of phone is True.....
                if str(password) in str(self.client_details_list):  ## Check Details of password is True.....
                    self.loggedin = True




##### If Details is True , then this will  "logged in"
          
            if self.loggedin == True:
                print(f"{name} logged in")
                self.amount = int(self.client_details_list[3])  ## Store amount position of [3], means indexing of list as a amount.....
                self.name = name
            
            else:                             ## If Details = False, Then......
                print("Wrong details !... Please Try Again...!")





##### Create a function for Withdraw  amount as a (  Withdraw_amount  ).....    
 
    def Withdraw_amount(self, amount):
        if amount > 0:                  ## Condition amount > 0:
            self.amount -= amount         ## First amount - New amount, will be Substract.....
            with open(f"{name}.txt","r") as f:  ## open read mode.....
                details = f.read()
                self.client_details_list = details.split("\n")
            
            with open(f"{name}.txt","w") as f:  ## Open write mode.....
                f.write(details.replace(str(self.client_details_list[3]),str(self.amount)))   ## first open as a "  write  " mode.....
                                                                                            ## replace Details indexing of [3], Old amount, from New " self.amount ".....
            print("Amount Withdraw successfully in Your Account...")
            print('Your Remaining Balance = %d' %Bank_object.amount)

        else:                                     ## if condition will be not True.....Then
            print("Enter correct value of amount.")




    
##### Create a function for Deposite amount as a (  Deposite_amount  ).....    
    
    def Deposite_amount(self, amount):
        if amount > 0:                  ## Condition amount > 0:
            self.amount += amount         ## First amount + New amount, will be added.....
            with open(f"{name}.txt","r") as f:  ## open read mode.....
                details = f.read()
                self.client_details_list = details.split("\n")
            
            with open(f"{name}.txt","w") as f:  ## Open write mode.....
                f.write(details.replace(str(self.client_details_list[3]),str(self.amount)))   ## first open as a "  write  " mode.....
                                                                                            ## replace Details indexing of [3], Old amount, from New " self.amount ".....
            print("Amount Deposited successfully in Your Account...")
            print('Your Remaining Balance = %d' %Bank_object.amount)

        else:                                     ## if condition will be not True.....Then
            print("Enter correct value of amount.")




##### Create a function for Transfer amount as a (  Transfer_amount  )..... 

    def Transfer_amount(self, amount , name , phone):
        with open(f"{name}.txt","r") as f:           ## open read ("r") mode.....
            details = f.read()
            self.client_details_list = details.split("\n")
            if str(phone) in self.client_details_list:     ## Check Phone Number is True.....
                self.TransferAmount = True

        
        if self.TransferAmount == True:
            total_amount = int(self.client_details_list[3]) + amount  ## Client_details indexing in [3], Old amount + New amount.....
            left_amount = self.amount - amount                      ## left_amount = Old amount - New amount
            with open(f"{name}.txt","w") as f:    ## open write ("w") mode.....
                f.write(details.replace(str(self.client_details_list[3]),str(total_amount)))  ## first open as a "  write  " mode.....
                                                                                               ## replace Details indexing of [3], Old amount, from New amount " total_amount ".....
            with open(f"{self.name}.txt","r") as f:
                details_2 = f.read()
                self.client_details_list = details.split("\n")
            
            with open(f"{self.name}.txt","w") as f:
                f.write(details_2.replace(str(self.client_details_list[3]),str(left_amount)))  ## By opening a file store left_amount.....

            print("Amount Transfered Successfully From Your Account to", name ,"-", "Phone Number is", "-" , phone)
            print("Balacne left = ",left_amount)
    


    ##### Create a function for Password Change as a (  Password_change  ).....

    def Password_change(self, password):
        if len(password) < 5 or len(password) > 15:    ## Condition for Password Length.....
            print("Enter Password greater than 5 and less than 15 Numbers.")
        else:
            with open(f"{self.name}.txt","r") as f:     ## open file read ("r") mode.....
                details = f.read()
                self.client_details_list = details.split("\n")

            with open(f"{self.name}.txt","w") as f:      ## open file as write("w") mode, for replace Password.....
                f.write(details.replace(str(self.client_details_list[2]),str(password)))   ## replace Details indexing of [2], Old Password, from New Password " Password_change ".....
            print("New Password Change successfully...")
        


    ##### Create a function for Password Change as a (  Password_change  ).....

    def Phone_change(self , phone):
        if len(str(phone)) > 10 or len(str(phone)) < 10:      ## Condition for Phone Number Length.....
            print("Invalid Phone number ! please enter 10 digit numbers.")
        else:
            with open(f"{self.name}.txt","r") as f:          ## open file read ("r") mode.....
                details = f.read()
                self.client_details_list = details.split("\n")

            with open(f"{self.name}.txt","w") as f:            ## open file as write("w") mode, for replace Password.....
                f.write(details.replace(str(self.client_details_list[1]),str(phone)))
            print("New Phone number Change successfully...")



 
if __name__ == "__main__":
    Bank_object = Bank()   ## Make a object as = Bank_object.....
    print("-------------------------------------------------------------\n\n")
    print("******************  WELCOME TO MY BANK  ********************\n")
    print("-------------------------------------------------------------")
    print("1.LOGIN : ")
    print("2.CREATE A NEW ACCOUNT : ")
    user = int(input("SELECT  OPTIONS : "))   ## If there is no any account,then first user will create a account.....




#####  For creating a new account required parameter.....
    
    if user == 1:
        print("Logging in...")
        name = input("Enter Your Full Name : ")
        phone = int(input("Enter Your Phone Number : "))
        password = input("Enter Your password : ")
        Bank_object.login(name, phone, password)
        while True:
            if Bank_object.loggedin:
                print("1. Withdraw AMOUNT : ")
                print("2. DEPOSITE AMOUNT : ")
                print("3. CHECK BALANCE : ")
                print("4. TRANSFER AMOUNT : ")
                print("5. EDIT PROFILE : ")
                print("6. LOGOUT : ")
                login_user = int(input())




    ##### The Code Below, Which is for the User Withdraw an Amount.....

                if login_user == 1:
                    print("Balance = ",Bank_object.amount)   
                    amount = int(input("Enter amount : "))
                    Bank_object.Withdraw_amount(amount)
                    print("\n1.BACK MENU.")       ## For Back Or Logout.....
                    print("2.LOGOUT.")
                    choose = int(input())
                    if choose == 1:
                        continue
                    elif choose == 2:
                        break



    
##### The Code Below, Which is for the User Deposit an Amount.....

                if login_user == 2:
                    print("Balance = ",Bank_object.amount)
                    amount = int(input("Enter amount: "))
                    Bank_object.Deposite_amount(amount)
                    print("\n1.BACK MENU.")
                    print("2.LOGOUT.")
                    choose = int(input())
                    if choose == 1:
                        continue
                    elif choose == 2:
                        break




##### The Code Below, Which is for the User Check Balance.....

                elif login_user == 3:
                    print("Balacne = ",Bank_object.amount)   ## Only print user Balance.....
                    print("\n1.BACK MENU.")
                    print("2.LOGOUT.")
                    choose = int(input())
                    if choose == 1:
                        continue
                    elif choose == 2:
                        break




##### The Code Below, Which is for the User Transfer an Amount.....   

                elif login_user == 4:
                    print("Balance = ",Bank_object.amount)
                    amount = int(input("Enter amount: "))
                    if amount >= 0 and amount <= Bank_object.amount:  ## Check Condition..... 
                        name = input("Enter User name : ")
                        phone = input("Enter User Phone number : ")
                        Bank_object.Transfer_amount(amount, name , phone)  ## Call the Transfer_amount function.....
                        print("\n1.BACK MENU.")
                        print("2.LOGOUT.")
                        choose = int(input())
                        if choose == 1:
                            continue
                        elif choose == 2:
                            break
                    elif amount < 0 :     ## Given  Condition.....
                        print("Enter please correct value of amount.")

                    elif amount > Bank_object.amount:
                        print("Not enough balance.")




##### The Code Below, Which is for the User Edit Profile.....
      
                elif login_user == 5:
                    print("1.Password change.")
                    print("2.Phone Number change.")
                    edit_profile = int(input())
                    if edit_profile == 1:         ## Check Condition for Password_Change.....
                        new_passwrod = input("Enter new Password : ")  ## Enter New Password.....
                        Bank_object.Password_change(new_passwrod)   ## For password.....
                        print("\n1.BACK MENU.") 
                        print("2.LOGOUT.")
                        choose = int(input())
                        if choose == 1:
                            continue
                        elif choose == 2:
                            break
                    elif edit_profile == 2:        ## Check Condition for Phone_Number.....
                        new_phone = int(input("Enter new Phone Number : "))   ## Enter New_Phone.....
                        Bank_object.phone_change(new_phone)              ## For Phone.....
                        print("\n1.BACK MENU.")
                        print("2.LOGOUT.")
                        choose = int(input())
                        if choose == 1:
                            continue
                        elif choose == 2:
                            break




##### The Code Below, Which is for the User Logout from Account.....   
   
   
                elif login_user == 6:
                    print("*****     THANK  YOU  USING  ME...!!     *****")
                    break
                        
                
    if user == 2:
        print("Creating a New  Account : ")
        name = input("Enter Your Full Name : ")
        phone = int(input("Enter Your Phone Number : "))
        password = input("Enter Your password : ")
        Bank_object.register(name, phone, password)     ## Give Arguments in Register form.....
        choose = int(input())